# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    iszero.py                                          :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/26 14:40:47 by arajapak          #+#    #+#              #
#    Updated: 2024/11/26 14:41:14 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
#!/bin/python3

#get variable 
number = float(input("Please enter number: "))

#compaire
if number == 0 :
    print("This number is equal to zero")

else:
    print("The number is different from zero ")
