#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    upcase_it.py                                       :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/12/06 16:48:58 by arajapak          #+#    #+#              #
#    Updated: 2024/12/06 16:49:03 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
#!/bin/python3

#creer funtion with def for chain the charactor

def upcase_it(chain):
    return chain.upper()

print(upcase_it("hello"))

    

  


