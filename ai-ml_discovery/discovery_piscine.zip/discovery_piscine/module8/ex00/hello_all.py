#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    hello_all.py                                       :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/12/06 16:48:03 by arajapak          #+#    #+#              #
#    Updated: 2024/12/06 16:48:09 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
#!/bun/python3

#creer funtion with def
def hello():
  print("Hello, everyone!")
  
#appelle funtion with nom de funtion hello
hello()

