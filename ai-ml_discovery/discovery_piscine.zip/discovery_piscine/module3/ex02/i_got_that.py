#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    i_got_that.py                                      :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/28 12:20:52 by arajapak          #+#    #+#              #
#    Updated: 2024/11/28 12:21:02 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/python3
#get variable user input with countinusly
#condition with while loop and break with STOP
#condition with while loop break


while True:
    get_text = input("What you gotta say? : \ n")
    print("I got that! Anything else: " ,get_text)

    if get_text == "STOP":
      break
   
  
        
