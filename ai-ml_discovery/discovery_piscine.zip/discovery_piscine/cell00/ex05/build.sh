#!/bin/bash
if [ $# -eq 0 ];
then
	echo "No arguments suppllied"
exit 0
fi
	for ARG in $@
	do mkdir "ex$ARG"
	done
