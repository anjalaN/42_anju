#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    upcase_it.py                                       :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/29 16:08:34 by arajapak          #+#    #+#              #
#    Updated: 2024/11/29 16:08:34 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
#text = input("Give me a word: ")
#x = text.upper()
#print(x)

print(input("Give me a word: ").upper())

