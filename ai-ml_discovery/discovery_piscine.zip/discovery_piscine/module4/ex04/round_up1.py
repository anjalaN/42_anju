#!/usr/bin/env python3
import math

number = float(input("Give me a number: "))
print(math.ceil(number))
