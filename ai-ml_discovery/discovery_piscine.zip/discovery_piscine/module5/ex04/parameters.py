#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    parameters.py                                      :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/12/02 12:46:27 by arajapak          #+#    #+#              #
#    Updated: 2024/12/02 12:46:32 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

import sys
arge_lenght=len(sys.argv)
number_argv=arge_lenght-1
print("Number of parameters: ",number_argv)