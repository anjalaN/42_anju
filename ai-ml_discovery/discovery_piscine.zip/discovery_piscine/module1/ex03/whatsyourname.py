# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    whatsyourname.py                                   :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/25 11:24:58 by arajapak          #+#    #+#              #
#    Updated: 2024/11/25 11:25:02 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/python3
#creerget and store variable with input
fname = input("Hey, what's your first name?")
lname = input("And your last name?")

#appelle variable
print ("Well, pleased to meet you " + fname + " " + lname)
