# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    age.py                                             :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/25 11:23:48 by arajapak          #+#    #+#              #
#    Updated: 2024/11/25 11:24:06 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/python3
#declaration variable
age = 25
age2 = 42

#concaténation
my_age = age + age2

#appelle variable
print(my_age)
