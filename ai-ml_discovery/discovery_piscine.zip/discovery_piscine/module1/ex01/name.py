# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    name.py                                            :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/11/25 11:15:56 by arajapak          #+#    #+#              #
#    Updated: 2024/11/25 11:16:18 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/python3
#creer variable
first_name = "Will"
last_name = "42"

#concaténation
whole_name = first_name + " " +  last_name

#appelle variable
print(whole_name)
