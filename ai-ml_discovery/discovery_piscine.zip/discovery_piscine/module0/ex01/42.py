#!/bin/python3
print("42")
