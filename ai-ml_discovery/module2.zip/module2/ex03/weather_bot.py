
#!/usr/bin/env python3

# import re
# import requests

# def get_weather_details(location):
    
#     api_key = "9d8e100fbf99d17abae7be5486ff297f"  # Replace with your API key
#     base_url = "http://api.openweathermap.org/data/2.5/weather"
#     params = {
#         "q": location,
#         "appid": api_key,
#         "units": "metric"  # Use metric units for temperature in °C
#     }
#     try:
#         response = requests.get(base_url, params=params)
#         data = response.json()

#         if response.status_code == 200:
#             temp = data['main']['temp']
#             humidity = data['main']['humidity']
#             cloudiness = data['clouds']['all']
#             wind_speed = data['wind']['speed']

#             cloud_description = "no clouds" if cloudiness == 0 else f"{cloudiness}% cloudiness"
#             return (
#                 f"The current weather in {location} is:\n"
#                 f"- Temperature: {temp}°C\n"
#                 f"- Humidity: {humidity}%\n"
#                 f"- Cloudiness: {cloud_description}\n"
#                 f"- Wind speed: {wind_speed} km/h."
#             )
#         else:
#             return f"Could not find weather information for {location}. Please try another location."
#     except Exception as e:
#         return f"An error occurred: {e}"

# def chatbot():
#     print("Welcome to Weather Bot!")
#     print("Ask me about the current weather in any city. Type 'exit' to quit.")
#     while True:
#         question = input("Ask?: ")
#         if question.lower() in ["exit", "quit"]:
#             print("Goodbye!")
#             break
#         if "weather" in question.lower():
#             match = re.search(r"in ([\w\s]+)", question)
#             if match:
#                 location = match.group(1).strip()
#                 print(get_weather_details(location))
#             else:
#                 print("Please specify a location. For example: 'What is the weather in Paris?'")
#         else:
#             print("I can only answer weather-related questions. Try asking about the weather.")

# if __name__ == "__main__":
#     chatbot()

import re
import requests
import datetime
import pytz

def get_weather_details(location):
    """
    Fetch detailed weather information for a given location.
    """
    api_key = "9d8e100fbf99d17abae7be5486ff297f"  # Replace with your API key
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": location,
        "appid": api_key,
        "units": "metric"  # Use metric units for temperature in °C
    }
    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if response.status_code == 200:
            temp = data['main']['temp']
            humidity = data['main']['humidity']
            cloudiness = data['clouds']['all']
            wind_speed = data['wind']['speed']

            cloud_description = "no clouds" if cloudiness == 0 else f"{cloudiness}% cloudiness"
            return temp, humidity, cloud_description, wind_speed
        else:
            return None
    except Exception as e:
        return f"An error occurred: {e}"

def get_local_time(location):
    """
    Get the local time for a given location.
    """
    try:
        # Set up timezone lookup
        # Using the timezone API or library like pytz to get the timezone (You can use OpenWeather's timezone data)
        timezone_mapping = {
            'paris': 'Europe/Paris',
            'new york': 'America/New_York',
            'london': 'Europe/London',
            'tokyo': 'Asia/Tokyo'
        }
        
        location = location.lower()
        if location in timezone_mapping:
            timezone = pytz.timezone(timezone_mapping[location])
            local_time = datetime.datetime.now(timezone).strftime('%Y-%m-%d %H:%M:%S')
            return local_time
        else:
            return "Sorry, I don't have time information for that location."
    
    except Exception as e:
        return f"An error occurred: {e}"

def chatbot():
    print("Welcome to Weather Bot!")
    print("Ask me about the weather, temperature, or time in any city. Type 'exit' to quit.")
    while True:
        question = input("Ask?: ")
        if question.lower() in ["exit", "quit"]:
            print("Goodbye!")
            break
        
        # Clean the input to allow multi-word locations
        question = question.strip().lower()

        if "weather" in question:
            match = re.search(r"in ([\w\s]+)", question)
            if match:
                location = match.group(1).strip()
                result = get_weather_details(location)
                if result:
                    temp, humidity, cloud_description, wind_speed = result
                    print(f"The current weather in {location} is:\n"
                          f"- Temperature: {temp}°C\n"
                          f"- Humidity: {humidity}%\n"
                          f"- Cloudiness: {cloud_description}\n"
                          f"- Wind speed: {wind_speed} km/h.")
                else:
                    print(f"Could not find weather information for {location}. Please try another location.")
            else:
                print("Please specify a location. For example: 'What is the weather in Paris?'")
        
        elif "temperature" in question:
            match = re.search(r"in ([\w\s]+)", question)
            if match:
                location = match.group(1).strip()
                result = get_weather_details(location)
                if result:
                    temp, _, _, _ = result
                    print(f"The current temperature in {location} is {temp}°C.")
                else:
                    print(f"Could not find temperature information for {location}. Please try another location.")
        
        elif "time" in question:
            match = re.search(r"in ([\w\s]+)", question)
            if match:
                location = match.group(1).strip()
                time_info = get_local_time(location)
                print(f"The current local time in {location} is: {time_info}")
            else:
                print("Please specify a location. For example: 'What is the time in Paris?'")
        
        else:
            print("I can only answer weather-related questions. Try asking about the weather, temperature, or time.")

if __name__ == "__main__":
    chatbot()
