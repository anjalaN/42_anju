#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    puzzle_solver_ad.py                                :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: arajapak <marvin@42.fr>                    +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/12/16 15:28:55 by arajapak          #+#    #+#              #
#    Updated: 2024/12/16 15:28:59 by arajapak         ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
#!/usr/bin/env python3
from collections import deque
import sys
import random
import os

# Goal state of the puzzle
goal_state = [1, 2, 3, 4, 5, 6, 7, 8, 0]
# Possible moves (up, down, left, right)
moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]


def is_goal(state):
    """Check if the current state matches the goal state."""
    return state == goal_state


def get_possible_moves(puzzle):
    """Return all possible states that can be reached by moving the empty space (0)."""
    if 0 not in puzzle:
        print("Error : puzzle must include 0 (empty space")
        sys.exit(1)
    index_of_zero = puzzle.index(0)
    row, col = divmod(index_of_zero, 3)
    possible_moves = []

    for move in moves:
        new_row, new_col = row + move[0], col + move[1]
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_index = new_row * 3 + new_col
            new_puzzle = puzzle[:]
            new_puzzle[index_of_zero], new_puzzle[new_index] = new_puzzle[new_index], new_puzzle[index_of_zero]
            possible_moves.append(new_puzzle)

    return possible_moves


def is_solvable(puzzle):
    """Check if the puzzle is solvable based on the number of inversions."""
    inversions = 0
    puzzle = [x for x in puzzle if x != 0]  # Remove the empty space (0)
    
    # Count inversions
    for i in range(len(puzzle)):
        for j in range(i + 1, len(puzzle)):
            if puzzle[i] > puzzle[j]:
                inversions += 1

    return inversions % 2 == 0



def bfs(start_state):
    """Perform breadth-first search to find the shortest solution to the puzzle."""
    if is_goal(start_state):
        return [start_state]
    
    queue = deque([(start_state, [])])  # Queue stores (state, path)
    visited = set()
    visited.add(tuple(start_state))  # Add the start state to visited

    while queue:
        current_state, path = queue.popleft()

        # Explore all possible moves
        for next_state in get_possible_moves(current_state):
            if tuple(next_state) not in visited:
                visited.add(tuple(next_state))
                new_path = path + [next_state]

                # If the next state is the goal, return the solution path
                if is_goal(next_state):
                    return new_path
                queue.append((next_state, new_path))

    return []  # No solution found




def print_puzzle(puzzle):
    """Print the current state of the puzzle."""
    for i in range(0, len(puzzle), 3):
        print(puzzle[i:i+3])
    print()


def load_from_file(filename):
    """Load the puzzle state from a file."""
    if not os.path.exists(filename):
        print(f"File {filename} does not exist.")
        return None
    
    with open(filename, 'r') as f:
        puzzle = list(map(int, f.read().split()))
    
    if len(puzzle) != 9:
        print(f"Invalid puzzle size in {filename}. Must be 9 numbers.")
        return None
    
    return puzzle


def main():
    # Accept the initial state from command line argument or generate a random one
    initial_state = None
    if len(sys.argv) == 10:
        try:
            # Try converting each argument to an integer
            initial_state = [int(arg) for arg in sys.argv[1:]]
        except ValueError:
            # Catch the ValueError if any input is not an integer
            print("Error: All inputs must be integers. Please provide a valid puzzle configuration.")
            sys.exit(1)
        
        # Check if 0 is included in the puzzle
        if 0 not in initial_state:
            print("Error: Puzzle must include 0 (empty space).")
            sys.exit(1)
        
        if not is_solvable(initial_state):
            print("The puzzle is unsolvable.")
            return
    elif len(sys.argv) == 2:  # File option
        filename = sys.argv[1]
        initial_state = load_from_file(filename)
        if initial_state is None or not is_solvable(initial_state):
            print("The puzzle is unsolvable.")
            return
    else:
        # Generate a random state
        initial_state = [1, 2, 3, 4, 0, 5, 6, 7, 8]  # Default solvable puzzle
        random.shuffle(initial_state)
        while not is_solvable(initial_state):
            random.shuffle(initial_state)
    
    # Display initial puzzle state
    print("Initial state of the puzzle:")
    print_puzzle(initial_state)

    # Solve the puzzle using BFS
    print("Solving the puzzle...")
    solution = bfs(initial_state)

    if not solution:
        print("The puzzle is unsolvable.")
    else:
        # Display the number of moves and the solution path
        print(f"Solution found in {len(solution) - 1} moves.")
        print("Solution path:")
        for i, step in enumerate(solution):
            print(f"Step {i + 1}:")
            print_puzzle(step)



if __name__ == "__main__":
    main()

