#!/usr/bin/env python3
from collections import deque
import sys
import random

# Goal state of the puzzle
goal_state = [1, 2, 3, 4, 5, 6, 7, 8, 0]
# Possible moves (up, down, left, right)
moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def is_goal(state):
    """Check if the current state matches the goal state."""
    return state == goal_state

def get_possible_moves(puzzle):
    """Return all possible states that can be reached by moving the empty space (0)."""
    if 0 not in puzzle:
        raise ValueError("Puzzle must contain the number 0 to represent the empty space.")
    
    index_of_zero = puzzle.index(0)
    row, col = divmod(index_of_zero, 3)
    possible_moves = []

    for move in moves:
        new_row, new_col = row + move[0], col + move[1]
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_index = new_row * 3 + new_col
            new_puzzle = puzzle[:]
            new_puzzle[index_of_zero], new_puzzle[new_index] = new_puzzle[new_index], new_puzzle[index_of_zero]
            possible_moves.append(new_puzzle)

    return possible_moves

def is_solvable(puzzle):
    """Check if the puzzle is solvable based on the number of inversions."""
    inversions = 0
    puzzle = [x for x in puzzle if x != 0]  # Remove the empty space (0)
    
    # Count inversions
    for i in range(len(puzzle)):
        for j in range(i + 1, len(puzzle)):
            if puzzle[i] > puzzle[j]:
                inversions += 1

    return inversions % 2 == 0
def print_puzzle(puzzle):
    """Print the current state of the puzzle."""
    if isinstance(puzzle, list):  # Check if the puzzle is a list (valid format)
        for i in range(0, len(puzzle), 3):
            print(puzzle[i:i+3])
        print()
    else:
        print("Error: Invalid puzzle format!")  # If it's not a list, print an error


def bfs(start_state):
    """Perform breadth-first search to find the shortest solution to the puzzle."""
    if is_goal(start_state):
        return [start_state]
    
    queue = deque([(start_state, [])])  # Queue stores (state, path)
    visited = set()
    visited.add(tuple(start_state))  # Add the start state to visited
    solutions = []  # List to store multiple solutions if needed

    while queue:
        current_state, path = queue.popleft()

        # Explore all possible moves
        for next_state in get_possible_moves(current_state):
            if tuple(next_state) not in visited:
                visited.add(tuple(next_state))
                new_path = path + [next_state]

                # If the next state is the goal, add it to solutions
                if is_goal(next_state):
                    solutions.append(new_path)
                queue.append((next_state, new_path))

    # Debugging: Check if all elements in solutions are valid lists
    print("Debugging solutions format:")
    for sol in solutions:
        print(f"Solution step format: {type(sol)}")
        for step in sol:
            print(type(step))  # Check the type of each step

    return solutions
def main():
    initial_state = None

    # Accept the initial state from command line argument or generate a random one
    if len(sys.argv) == 10:  # 9 puzzle numbers (first argument is script name)
        try:
            # Attempt to convert the input arguments into integers
            initial_state = [int(arg) for arg in sys.argv[1:]]  # Get the numbers from command line
        except ValueError:
            print("Error: All puzzle numbers must be integers.")
            return
        
        # If the puzzle doesn't contain exactly 9 numbers
        if len(initial_state) != 9:
            print("Error: Puzzle must contain exactly 9 numbers (1-8 and 0 for the empty space).")
            return
        
        # Check if 0 (empty space) is present
        if 0 not in initial_state:
            print("Error: Puzzle must include 0 (empty space).")
            return
        
        # Check if the puzzle is solvable
        if not is_solvable(initial_state):
            print("The puzzle is unsolvable.")
            return
    else:  # If not 9 numbers are provided, generate a random puzzle
        initial_state = [1, 2, 3, 4, 0, 5, 6, 7, 8]
        random.shuffle(initial_state)
        while not is_solvable(initial_state):
            random.shuffle(initial_state)

    # Display initial puzzle state
    print("Initial state of the puzzle:")
    print_puzzle(initial_state)

    # Solve the puzzle using BFS
    print("Solving the puzzle...")
    solutions = bfs(initial_state)

    if not solutions:
        print("The puzzle is unsolvable.")
    else:
        # Find the shortest solution (smallest path)
        shortest_solution = min(solutions, key=len)

        # Display the number of moves and the shortest path
        print(f"Shortest path found in {len(shortest_solution) - 1} moves.")
        print("Shortest path found:")
        for i, step in enumerate(shortest_solution):
            print(f"Step {i + 1}:")
            print_puzzle(step)

        # Display all solutions
        for solution in solutions:
            print(f"Solution found in {len(solution) - 1} moves.")
            for i, step in enumerate(solution):
                print(f"Step {i + 1}:")
                print_puzzle(step)



if __name__ == "__main__":
    main()
