# Check if the user has provided an argument
if [ -z "$1" ]; then
    echo "Usage: $0 <bit.ly-url>"
    exit 1
fi

# Use curl to get the header, follow redirects (-L), and extract the location header
curl -sIL "$1" | grep -i Location | cut -d ' ' -f2
